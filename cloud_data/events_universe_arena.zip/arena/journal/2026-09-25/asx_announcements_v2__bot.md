# Trading journal - asx_announcements_v2__bot - Fri 2026-09-25

ASX announcements v2 (trade the reaction), the rule bot's book (plain code, no model). day 1 of 10 (v2) - PARTIAL DAY (data failure - the IBKR history batch timed out at 07:30 and Gateway died 08:58-10:16, so seven reaction looks were lost as 'quiet' and the 10:30 rule bot was re-run late, at 10:53, after a mid-session restart).

> FROZEN TEST RULE: this journal is written only. During the 10-day test (Fri 25 Sep - Thu 08 Oct 2026) it is never fed back into the agents' prompts or decisions - not the watcher's packets, not the agents' standing instructions or memory, not the evening report's agent brief - so the test stays fair. It is a record for Rick and for the Practice Lab.
>
> Practice Lab: 25 Sep 2026 is inside WINNER.md's sealed LOCKED TEST window (17 Aug - 25 Sep 2026): never use this day to tune or screen a variant.

## The day's facts (plain code)

- Result: 2 round trips closed, 1 won after all costs; net +194.42, brokerage 26.40, slippage 15.06; the book's day after fees (marked) +194.42

### Trades
- HLS long 6554: decided 10:53, limit 0.4 (set by the frozen rule, as was the size); in 0.3891 at 10:54, out 0.3846 (closed 11:03); stop 0.385 (risk $27.05); gross after slippage -29.59, net -42.79 (-1.58R net); costs 18.31 = brokerage 13.20 + slippage 5.11 (in the fill prices)
  - why in: v2 rule: +9.30% vs the ASX 200 at 10:30 on 4.5x usual first-30-minute volume
  - exit: ARN-000008 sell 6554 @ 0.3846 at 11:02: STOP hit at 0.385
- NWL short 285: decided 10:53, limit 17.51 (set by the frozen rule, as was the size); in 17.8656 at 10:54, out 16.987 (closed 15:56); stop 18.34 (risk $135.19); gross after slippage +250.41, net +237.21 (+1.75R net); costs 23.15 = brokerage 13.20 + slippage 9.95 (in the fill prices)
  - why in: v2 rule: -3.15% vs the ASX 200 at 10:30 on 6.1x usual first-30-minute volume
  - exit: ARN-000018 cover 285 @ 16.987 at 15:56: flat at the close: ASX announcements v2 (trade the reaction) holds intraday only (the rule

### The rule at 10:30
- status done, decided 10:53, on live data (IBKR)
- SIGNAL HLS: +9.30% vs the ASX 200 at 10:30 on 4.5x usual first-30-minute volume
- SIGNAL NWL: -3.15% vs the ASX 200 at 10:30 on 6.1x usual first-30-minute volume
- no signal AUE: +1.34% vs the ASX 200 at 10:30 on 0.1x usual first-30-minute volume: volume below 3.0x
- no signal BMN: -2.71% vs the ASX 200 at 10:30 on 2.0x usual first-30-minute volume: volume below 3.0x
- no signal GBR: +12.50% vs the ASX 200 at 10:30 on 2.9x usual first-30-minute volume: volume below 3.0x
- no signal ING: +1.88% vs the ASX 200 at 10:30 on 2.2x usual first-30-minute volume: volume below 3.0x
- no signal LKE: -2.03% vs the ASX 200 at 10:30 on 1.1x usual first-30-minute volume: volume below 3.0x
- no signal MEK: -25.51% vs the ASX 200 at 10:30 on 5.5x usual first-30-minute volume: would be a short, but not an ASX 200 member
- no signal MOT: -0.21% vs the ASX 200 at 10:30 on 0.9x usual first-30-minute volume: volume below 3.0x
- no signal MRE: +0.41% vs the ASX 200 at 10:30 on 5.9x usual first-30-minute volume: move inside +/-3.0%
- no signal MXT: +0.41% vs the ASX 200 at 10:30 on 2.3x usual first-30-minute volume: volume below 3.0x
- no signal PEN: -1.51% vs the ASX 200 at 10:30 on 5.3x usual first-30-minute volume: move inside +/-3.0%
- no signal TGN: -2.92% vs the ASX 200 at 10:30 on 0.5x usual first-30-minute volume: volume below 3.0x
- screened out on turnover before measuring: 30

Written by: plain code (a rule bot keeps facts, not a journal; no model call).

## Data (for the Practice Lab)

```json journal-data
{
 "version": 1,
 "frozen_test_rule": "FROZEN TEST RULE: this journal is written only. During the 10-day test (Fri 25 Sep - Thu 08 Oct 2026) it is never fed back into the agents' prompts or decisions - not the watcher's packets, not the agents' standing instructions or memory, not the evening report's agent brief - so the test stays fair. It is a record for Rick and for the Practice Lab.",
 "locked_test_day": true,
 "facts": {
  "day": "2026-09-25",
  "weekday": "Fri",
  "account": "asx_announcements_v2__bot",
  "playbook": "asx_announcements_v2",
  "title": "ASX announcements v2 (trade the reaction)",
  "kind": "bot",
  "test": "day 1 of 10 (v2) - PARTIAL DAY (data failure - the IBKR history batch timed out at 07:30 and Gateway died 08:58-10:16, so seven reaction looks were lost as 'quiet' and the 10:30 rule bot was re-run late, at 10:53, after a mid-session restart)",
  "partial": "data failure - the IBKR history batch timed out at 07:30 and Gateway died 08:58-10:16, so seven reaction looks were lost as 'quiet' and the 10:30 rule bot was re-run late, at 10:53, after a mid-session restart",
  "trades": [
   {
    "ticker": "HLS",
    "side": "long",
    "qty": 6554,
    "opened": "10:54",
    "closed": "11:03",
    "still_open": false,
    "entry": 0.3891,
    "exit": 0.3846,
    "initial_stop": 0.385,
    "risk_aud": 27.05,
    "gross": -29.59,
    "fees": 13.2,
    "borrow": 0.0,
    "slippage": 5.11,
    "slippage_known": true,
    "costs_all_in": 18.31,
    "net": -42.79,
    "r_net": -1.58,
    "r_gross": -1.09,
    "entry_order": "ARN-000005",
    "entry_limit": 0.4,
    "limit_by": "set by the frozen rule, as was the size",
    "decided": "10:53",
    "entry_reason": "v2 rule: +9.30% vs the ASX 200 at 10:30 on 4.5x usual first-30-minute volume",
    "model": "none (rule-based bot)",
    "exits": [
     "ARN-000008 sell 6554 @ 0.3846 at 11:02: STOP hit at 0.385"
    ],
    "management": []
   },
   {
    "ticker": "NWL",
    "side": "short",
    "qty": 285,
    "opened": "10:54",
    "closed": "15:56",
    "still_open": false,
    "entry": 17.8656,
    "exit": 16.987,
    "initial_stop": 18.34,
    "risk_aud": 135.19,
    "gross": 250.41,
    "fees": 13.2,
    "borrow": 0.0,
    "slippage": 9.95,
    "slippage_known": true,
    "costs_all_in": 23.15,
    "net": 237.21,
    "r_net": 1.75,
    "r_gross": 1.85,
    "entry_order": "ARN-000004",
    "entry_limit": 17.51,
    "limit_by": "set by the frozen rule, as was the size",
    "decided": "10:53",
    "entry_reason": "v2 rule: -3.15% vs the ASX 200 at 10:30 on 6.1x usual first-30-minute volume",
    "model": "none (rule-based bot)",
    "exits": [
     "ARN-000018 cover 285 @ 16.987 at 15:56: flat at the close: ASX announcements v2 (trade the reaction) holds intraday only (the rule"
    ],
    "management": []
   }
  ],
  "result": {
   "round_trips_closed": 2,
   "wins_after_fees": 1,
   "net_closed": 194.42,
   "fees": 26.4,
   "still_open": [],
   "today_after_fees": 194.42
  },
  "rule": {
   "status": "done",
   "why": null,
   "decided_at": "10:53",
   "data": "live data (IBKR)",
   "signals": [
    {
     "ticker": "HLS",
     "why": "+9.30% vs the ASX 200 at 10:30 on 4.5x usual first-30-minute volume"
    },
    {
     "ticker": "NWL",
     "why": "-3.15% vs the ASX 200 at 10:30 on 6.1x usual first-30-minute volume"
    }
   ],
   "no_signal": [
    {
     "ticker": "AUE",
     "why": "+1.34% vs the ASX 200 at 10:30 on 0.1x usual first-30-minute volume: volume below 3.0x"
    },
    {
     "ticker": "BMN",
     "why": "-2.71% vs the ASX 200 at 10:30 on 2.0x usual first-30-minute volume: volume below 3.0x"
    },
    {
     "ticker": "GBR",
     "why": "+12.50% vs the ASX 200 at 10:30 on 2.9x usual first-30-minute volume: volume below 3.0x"
    },
    {
     "ticker": "ING",
     "why": "+1.88% vs the ASX 200 at 10:30 on 2.2x usual first-30-minute volume: volume below 3.0x"
    },
    {
     "ticker": "LKE",
     "why": "-2.03% vs the ASX 200 at 10:30 on 1.1x usual first-30-minute volume: volume below 3.0x"
    },
    {
     "ticker": "MEK",
     "why": "-25.51% vs the ASX 200 at 10:30 on 5.5x usual first-30-minute volume: would be a short, but not an ASX 200 member"
    },
    {
     "ticker": "MOT",
     "why": "-0.21% vs the ASX 200 at 10:30 on 0.9x usual first-30-minute volume: volume below 3.0x"
    },
    {
     "ticker": "MRE",
     "why": "+0.41% vs the ASX 200 at 10:30 on 5.9x usual first-30-minute volume: move inside +/-3.0%"
    },
    {
     "ticker": "MXT",
     "why": "+0.41% vs the ASX 200 at 10:30 on 2.3x usual first-30-minute volume: volume below 3.0x"
    },
    {
     "ticker": "PEN",
     "why": "-1.51% vs the ASX 200 at 10:30 on 5.3x usual first-30-minute volume: move inside +/-3.0%"
    },
    {
     "ticker": "TGN",
     "why": "-2.92% vs the ASX 200 at 10:30 on 0.5x usual first-30-minute volume: volume below 3.0x"
    }
   ],
   "screened_out": 30
  },
  "decisions": 13
 },
 "entry": "",
 "lesson": "",
 "written_by": "code",
 "call": null
}
```
