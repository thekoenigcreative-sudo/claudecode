# Trading journal - asx_daytrader_v1__bot - Fri 2026-09-25

ASX day trader, the rule bot's book (plain code, no model). day 1 of 10 (v1).

> FROZEN TEST RULE: this journal is written only. During the 10-day test (Fri 25 Sep - Thu 08 Oct 2026) it is never fed back into the agents' prompts or decisions - not the watcher's packets, not the agents' standing instructions or memory, not the evening report's agent brief - so the test stays fair. It is a record for Rick and for the Practice Lab.
>
> Practice Lab: 25 Sep 2026 is inside WINNER.md's sealed LOCKED TEST window (17 Aug - 25 Sep 2026): never use this day to tune or screen a variant.

## The day's facts (plain code)

- Result: 3 round trips closed, 1 won after all costs; net +117.65, brokerage 46.20, slippage 24.50; the book's day after fees (marked) +117.65

### Trades
- NWL short 208: decided 11:20, limit 17.59 (set by the frozen rule, as was the size); in 17.6223 at 11:21, out 16.8954 (closed 15:51); stop 18.07 (risk $93.11); gross after slippage +151.20, net +131.40 (+1.41R net); costs 26.99 = brokerage 19.80 + slippage 7.19 (in the fill prices)
  - why in: [opening_range_breakout] rule: closed 17.77 below the 30-min low 17.8 on 2.5x the prior 10 bars' volume, RVOL 3.0
  - exit: ARN-000017 cover 104 @ 16.7437 at 15:30: HALF at +2.0R (16.7270)
  - exit: ARN-000014 cover 104 @ 17.047 at 15:51: flat at the close: ASX day trader holds intraday only (the sweep runs at 15:50)
  - code moved the stop 18.07 -> 17.62 at 12:49, +1.01R in hand (trade management by code, not the agent)
  - code moved the stop 17.6223 -> 17.17 at 15:30, +2.02R in hand (trade management by code, not the agent)
  - code moved the stop 17.1677 -> 17.15 at 15:35, +2.06R in hand (trade management by code, not the agent)
  - code moved the stop 17.1477 -> 17.14 at 15:36, +2.08R in hand (trade management by code, not the agent)
- DOW long 737: decided 11:20, limit 6.78 (set by the frozen rule, as was the size); in 6.7004 at 11:22, out 6.7083 (closed 15:51); stop 6.65 (risk $37.17); gross after slippage +5.78, net -7.42 (-0.20R net); costs 23.10 = brokerage 13.20 + slippage 9.90 (in the fill prices)
  - why in: [opening_range_breakout] rule: closed 6.71 above the 30-min high 6.69 on 8.3x the prior 10 bars' volume, RVOL 2.1
  - exit: ARN-000015 sell 737 @ 6.7083 at 15:51: flat at the close: ASX day trader holds intraday only (the sweep runs at 15:50)
- CWY short 1428: decided 11:24, limit 2.57 (set by the frozen rule, as was the size); in 2.5974 at 11:25, out 2.5926 (closed 15:51); stop 2.64 (risk $60.83); gross after slippage +6.87, net -6.33 (-0.10R net); costs 20.61 = brokerage 13.20 + slippage 7.41 (in the fill prices)
  - why in: [opening_range_breakout] rule: closed 2.605 below the 30-min low 2.625 on 49.3x the prior 10 bars' volume, RVOL 1.9
  - exit: ARN-000016 cover 1428 @ 2.5926 at 15:51: flat at the close: ASX day trader holds intraday only (the sweep runs at 15:50)

### Setups decided
- 11:20 NWL opening_range_breakout short at 17.77, stop 18.07: **TOOK** - the rule took it
  - after: +1R at 11:28 before the stop, +2R 12:52; at 15:50 +2.4R (price path before costs, no trade management)
- 11:20 DOW opening_range_breakout buy at 6.71, stop 6.65: **TOOK** - the rule took it
  - after: neither the stop nor +1R by 15:50; at 15:50 +0.0R (price path before costs, no trade management)
- 11:24 CWY opening_range_breakout short at 2.605, stop 2.6325: **TOOK** - the rule took it
  - after: neither the stop nor +1R by 15:50; at 15:50 +0.7R (price path before costs, no trade management)
- 11:24 DYL vwap_reclaim short at 1.267, stop 1.27: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 11:27 before +1R; at 15:50 +7.3R (price path before costs, no trade management)
- 11:26 HDN opening_range_breakout short at 1.06, stop 1.0725: **SKIPPED** - the account is full (3 open or working)
  - after: neither the stop nor +1R by 15:50; at 15:50 +0.4R (price path before costs, no trade management)
- 11:27 REG vwap_reclaim short at 4.535, stop 4.565: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 11:53 before the stop, +2R 15:49; at 15:50 +1.8R (price path before costs, no trade management)
- 11:27 MND vwap_reclaim short at 31.2, stop 31.33: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 11:30 before the stop, +2R 12:34; at 15:50 +2.5R (price path before costs, no trade management)
- 11:31 CSC vwap_reclaim short at 14.43, stop 14.46: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 11:44 before +1R; at 15:50 -2.3R (price path before costs, no trade management)
- 11:32 ZIM opening_range_breakout short at 15.0, stop 15.09: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 11:45 before the stop, +2R 12:16; at 15:50 +3.1R (price path before costs, no trade management)
- 11:32 NXG vwap_reclaim short at 13.09, stop 13.15: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 11:47 before +1R; at 15:50 -1.0R (price path before costs, no trade management)
- 11:38 AUB opening_range_breakout short at 26.96, stop 27.62: **SKIPPED** - the account is full (3 open or working)
  - after: neither the stop nor +1R by 15:50; at 15:50 +0.2R (price path before costs, no trade management)
- 11:38 ORI opening_range_breakout short at 22.62, stop 23.0675: **SKIPPED** - the account is full (3 open or working)
  - after: neither the stop nor +1R by 15:50; at 15:50 -0.4R (price path before costs, no trade management)
- 11:38 XYZ vwap_reclaim buy at 108.85, stop 108.76: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 11:56 before +1R; at 15:50 -4.3R (price path before costs, no trade management)
- 11:40 CHC opening_range_breakout short at 17.63, stop 17.82: **SKIPPED** - the account is full (3 open or working)
  - after: neither the stop nor +1R by 15:50; at 15:50 +0.1R (price path before costs, no trade management)
- 11:47 AAI opening_range_breakout buy at 61.02, stop 60.65: **SKIPPED** - the account is full (3 open or working)
  - after: neither the stop nor +1R by 15:50; at 15:50 +0.3R (price path before costs, no trade management)
- 12:03 MIN vwap_reclaim short at 52.72, stop 52.83: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 12:04 before the stop, +2R 12:04; at 15:50 +5.7R (price path before costs, no trade management)
- 12:15 BRG vwap_reclaim short at 29.985, stop 30.03: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 12:24 before the stop, +2R 12:34; stop touched later (13:07); at 15:50 +1.4R (price path before costs, no trade management)
- 12:25 REA vwap_reclaim short at 148.21, stop 148.4: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 12:30 before +1R; at 15:50 +3.7R (price path before costs, no trade management)
- 12:33 SGM vwap_reclaim short at 24.25, stop 24.35: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 13:21 before +1R; at 15:50 +0.1R (price path before costs, no trade management)
- 12:47 PME vwap_reclaim short at 159.71, stop 160.24: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 13:02 before +1R; at 15:50 -3.3R (price path before costs, no trade management)
- 12:57 DRR opening_range_breakout short at 4.03, stop 4.145: **SKIPPED** - the account is full (3 open or working)
  - after: neither the stop nor +1R by 15:50; at 15:50 -0.2R (price path before costs, no trade management)
- 13:00 AIA vwap_reclaim buy at 6.93, stop 6.92: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 13:06 before +1R; at 15:50 -4.5R (price path before costs, no trade management)
- 13:00 ALL vwap_reclaim short at 58.12, stop 58.22: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 13:01 before +1R; at 15:50 -2.1R (price path before costs, no trade management)
- 13:20 CQR vwap_reclaim short at 3.56, stop 3.565: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 13:21 before +1R; at 15:50 +3.0R (price path before costs, no trade management)
- 13:29 PMV vwap_reclaim short at 11.76, stop 11.79: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 13:39 before the stop, +2R 13:46; at 15:50 +0.7R (price path before costs, no trade management)
- 13:31 IAG vwap_reclaim buy at 7.88, stop 7.87: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 13:32 before +1R; at 15:50 +1.0R (price path before costs, no trade management)
- 13:31 L1G vwap_reclaim short at 1.177, stop 1.18: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 13:36 before the stop, +2R 13:40; at 15:50 +5.7R (price path before costs, no trade management)
- 13:35 JBH vwap_reclaim short at 66.34, stop 66.47: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 14:12 before the stop; at 15:50 +0.3R (price path before costs, no trade management)
- 13:39 EOS vwap_reclaim buy at 11.31, stop 11.23: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 13:41 before the stop, +2R 13:46; at 15:50 +1.1R (price path before costs, no trade management)
- 13:56 PRN vwap_reclaim short at 2.19, stop 2.2: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 14:24 before +1R; at 15:50 -0.5R (price path before costs, no trade management)
- 14:00 MTS vwap_reclaim buy at 2.85, stop 2.84: **SKIPPED** - the account is full (3 open or working)
  - after: neither the stop nor +1R by 15:50; at 15:50 +1.0R (price path before costs, no trade management)
- 14:13 ORI vwap_reclaim short at 22.74, stop 22.77: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 14:16 before +1R; at 15:50 -2.2R (price path before costs, no trade management)
- 14:15 RPL opening_range_breakout buy at 2.265, stop 2.245: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 14:49 before the stop, +2R 15:42; at 15:50 +1.7R (price path before costs, no trade management)
- 14:15 APE vwap_reclaim short at 18.72, stop 18.77: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 14:36 before the stop, +2R 14:36; at 15:50 +3.8R (price path before costs, no trade management)
- 14:29 ORA vwap_reclaim short at 1.39, stop 1.395: **SKIPPED** - the account is full (3 open or working)
  - after: +1R at 14:48 before the stop; stop touched later (15:36); at 15:50 -1.0R (price path before costs, no trade management)
- 14:31 SDF opening_range_breakout buy at 5.76, stop 5.745: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 14:40 before +1R; at 15:50 -0.7R (price path before costs, no trade management)
- 14:51 REH vwap_reclaim short at 16.29, stop 16.305: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 14:53 before +1R; at 15:50 +3.3R (price path before costs, no trade management)
- 14:54 CIA vwap_reclaim short at 3.095, stop 3.11: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 15:44 before +1R; at 15:50 -1.0R (price path before costs, no trade management)
- 15:12 DRR vwap_reclaim short at 4.06, stop 4.07: **SKIPPED** - the account is full (3 open or working)
  - after: stop touched 15:14 before +1R; at 15:50 +0.5R (price path before costs, no trade management)

### Setups nobody decided (the system's facts)
- 28 x stale: the trigger bar is N bars old

Written by: plain code (a rule bot keeps facts, not a journal; no model call).

## Data (for the Practice Lab)

```json journal-data
{
 "version": 1,
 "frozen_test_rule": "FROZEN TEST RULE: this journal is written only. During the 10-day test (Fri 25 Sep - Thu 08 Oct 2026) it is never fed back into the agents' prompts or decisions - not the watcher's packets, not the agents' standing instructions or memory, not the evening report's agent brief - so the test stays fair. It is a record for Rick and for the Practice Lab.",
 "locked_test_day": true,
 "facts": {
  "day": "2026-09-25",
  "weekday": "Fri",
  "account": "asx_daytrader_v1__bot",
  "playbook": "asx_daytrader",
  "title": "ASX day trader",
  "kind": "bot",
  "test": "day 1 of 10 (v1)",
  "partial": "",
  "trades": [
   {
    "ticker": "NWL",
    "side": "short",
    "qty": 208,
    "opened": "11:21",
    "closed": "15:51",
    "still_open": false,
    "entry": 17.6223,
    "exit": 16.8954,
    "initial_stop": 18.07,
    "risk_aud": 93.11,
    "gross": 151.2,
    "fees": 19.8,
    "borrow": 0.0,
    "slippage": 7.19,
    "slippage_known": true,
    "costs_all_in": 26.99,
    "net": 131.4,
    "r_net": 1.41,
    "r_gross": 1.62,
    "entry_order": "ARN-000006",
    "entry_limit": 17.59,
    "limit_by": "set by the frozen rule, as was the size",
    "decided": "11:20",
    "entry_reason": "[opening_range_breakout] rule: closed 17.77 below the 30-min low 17.8 on 2.5x the prior 10 bars' volume, RVOL 3.0",
    "model": "none (rule-based bot)",
    "exits": [
     "ARN-000017 cover 104 @ 16.7437 at 15:30: HALF at +2.0R (16.7270)",
     "ARN-000014 cover 104 @ 17.047 at 15:51: flat at the close: ASX day trader holds intraday only (the sweep runs at 15:50)"
    ],
    "management": [
     "code moved the stop 18.07 -> 17.62 at 12:49, +1.01R in hand (trade management by code, not the agent)",
     "code moved the stop 17.6223 -> 17.17 at 15:30, +2.02R in hand (trade management by code, not the agent)",
     "code moved the stop 17.1677 -> 17.15 at 15:35, +2.06R in hand (trade management by code, not the agent)",
     "code moved the stop 17.1477 -> 17.14 at 15:36, +2.08R in hand (trade management by code, not the agent)"
    ]
   },
   {
    "ticker": "DOW",
    "side": "long",
    "qty": 737,
    "opened": "11:22",
    "closed": "15:51",
    "still_open": false,
    "entry": 6.7004,
    "exit": 6.7083,
    "initial_stop": 6.65,
    "risk_aud": 37.17,
    "gross": 5.78,
    "fees": 13.2,
    "borrow": 0.0,
    "slippage": 9.9,
    "slippage_known": true,
    "costs_all_in": 23.1,
    "net": -7.42,
    "r_net": -0.2,
    "r_gross": 0.16,
    "entry_order": "ARN-000007",
    "entry_limit": 6.78,
    "limit_by": "set by the frozen rule, as was the size",
    "decided": "11:20",
    "entry_reason": "[opening_range_breakout] rule: closed 6.71 above the 30-min high 6.69 on 8.3x the prior 10 bars' volume, RVOL 2.1",
    "model": "none (rule-based bot)",
    "exits": [
     "ARN-000015 sell 737 @ 6.7083 at 15:51: flat at the close: ASX day trader holds intraday only (the sweep runs at 15:50)"
    ],
    "management": []
   },
   {
    "ticker": "CWY",
    "side": "short",
    "qty": 1428,
    "opened": "11:25",
    "closed": "15:51",
    "still_open": false,
    "entry": 2.5974,
    "exit": 2.5926,
    "initial_stop": 2.64,
    "risk_aud": 60.83,
    "gross": 6.87,
    "fees": 13.2,
    "borrow": 0.0,
    "slippage": 7.41,
    "slippage_known": true,
    "costs_all_in": 20.61,
    "net": -6.33,
    "r_net": -0.1,
    "r_gross": 0.11,
    "entry_order": "ARN-000009",
    "entry_limit": 2.57,
    "limit_by": "set by the frozen rule, as was the size",
    "decided": "11:24",
    "entry_reason": "[opening_range_breakout] rule: closed 2.605 below the 30-min low 2.625 on 49.3x the prior 10 bars' volume, RVOL 1.9",
    "model": "none (rule-based bot)",
    "exits": [
     "ARN-000016 cover 1428 @ 2.5926 at 15:51: flat at the close: ASX day trader holds intraday only (the sweep runs at 15:50)"
    ],
    "management": []
   }
  ],
  "result": {
   "round_trips_closed": 3,
   "wins_after_fees": 1,
   "net_closed": 117.65,
   "fees": 46.2,
   "still_open": [],
   "today_after_fees": 117.65
  },
  "setups_decided": [
   {
    "at": "11:20",
    "ticker": "NWL",
    "setup": "opening_range_breakout",
    "side": "short",
    "last": 17.77,
    "stop": 18.07,
    "rvol": 3.0,
    "scanner": "closed 17.77 below the 30-min low 17.8 on 2.5x the prior 10 bars' volume, RVOL 3.0",
    "decision": "took",
    "why": "the rule took it",
    "order": "ARN-000006",
    "after": {
     "from": "11:21",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "11:28",
     "plus_2r": "12:52",
     "r_at_1550": 2.4,
     "best_r": 3.6,
     "worst_r": 0.0,
     "line": "+1R at 11:28 before the stop, +2R 12:52; at 15:50 +2.4R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:20",
    "ticker": "DOW",
    "setup": "opening_range_breakout",
    "side": "buy",
    "last": 6.71,
    "stop": 6.65,
    "rvol": 2.1,
    "scanner": "closed 6.71 above the 30-min high 6.69 on 8.3x the prior 10 bars' volume, RVOL 2.1",
    "decision": "took",
    "why": "the rule took it",
    "order": "ARN-000007",
    "after": {
     "from": "11:22",
     "first": "neither",
     "stop_touched": null,
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": 0.0,
     "best_r": 0.67,
     "worst_r": -0.33,
     "line": "neither the stop nor +1R by 15:50; at 15:50 +0.0R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:24",
    "ticker": "CWY",
    "setup": "opening_range_breakout",
    "side": "short",
    "last": 2.605,
    "stop": 2.6325,
    "rvol": 1.9,
    "scanner": "closed 2.605 below the 30-min low 2.625 on 49.3x the prior 10 bars' volume, RVOL 1.9",
    "decision": "took",
    "why": "the rule took it",
    "order": "ARN-000009",
    "after": {
     "from": "11:25",
     "first": "neither",
     "stop_touched": null,
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": 0.73,
     "best_r": 0.91,
     "worst_r": -0.18,
     "line": "neither the stop nor +1R by 15:50; at 15:50 +0.7R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:24",
    "ticker": "DYL",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 1.267,
    "stop": 1.27,
    "rvol": 1.4,
    "scanner": "down -1.8% vs index, VWAP falling, 16 of the last 20 bars above VWAP, closed back below it at 1.267 (VWAP 1.267)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:25",
     "first": "stop",
     "stop_touched": "11:27",
     "plus_1r": "11:30",
     "plus_2r": "12:16",
     "r_at_1550": 7.33,
     "best_r": 7.33,
     "worst_r": -2.67,
     "line": "stop touched 11:27 before +1R; at 15:50 +7.3R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:26",
    "ticker": "HDN",
    "setup": "opening_range_breakout",
    "side": "short",
    "last": 1.06,
    "stop": 1.0725,
    "rvol": 2.1,
    "scanner": "closed 1.06 below the 30-min low 1.065 on 73.6x the prior 10 bars' volume, RVOL 2.1",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:28",
     "first": "neither",
     "stop_touched": null,
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": 0.4,
     "best_r": 0.64,
     "worst_r": -0.4,
     "line": "neither the stop nor +1R by 15:50; at 15:50 +0.4R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:27",
    "ticker": "REG",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 4.535,
    "stop": 4.565,
    "rvol": 1.3,
    "scanner": "down -1.5% vs index, VWAP falling, 12 of the last 20 bars above VWAP, closed back below it at 4.535 (VWAP 4.548)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:28",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "11:53",
     "plus_2r": "15:49",
     "r_at_1550": 1.83,
     "best_r": 2.5,
     "worst_r": -0.5,
     "line": "+1R at 11:53 before the stop, +2R 15:49; at 15:50 +1.8R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:27",
    "ticker": "MND",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 31.2,
    "stop": 31.33,
    "rvol": 0.5,
    "scanner": "down -1.1% vs index, VWAP falling, 4 of the last 20 bars above VWAP, closed back below it at 31.2 (VWAP 31.27)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:28",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "11:30",
     "plus_2r": "12:34",
     "r_at_1550": 2.54,
     "best_r": 2.85,
     "worst_r": 0.0,
     "line": "+1R at 11:30 before the stop, +2R 12:34; at 15:50 +2.5R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:31",
    "ticker": "CSC",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 14.43,
    "stop": 14.46,
    "rvol": 0.7,
    "scanner": "down -1.2% vs index, VWAP falling, 3 of the last 20 bars above VWAP, closed back below it at 14.43 (VWAP 14.44)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:32",
     "first": "stop",
     "stop_touched": "11:44",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -2.33,
     "best_r": 0.83,
     "worst_r": -3.67,
     "line": "stop touched 11:44 before +1R; at 15:50 -2.3R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:32",
    "ticker": "ZIM",
    "setup": "opening_range_breakout",
    "side": "short",
    "last": 15.0,
    "stop": 15.09,
    "rvol": 4.5,
    "scanner": "closed 15 below the 30-min low 15.09 on 9.2x the prior 10 bars' volume, RVOL 4.5",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:33",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "11:45",
     "plus_2r": "12:16",
     "r_at_1550": 3.11,
     "best_r": 3.33,
     "worst_r": 0.0,
     "line": "+1R at 11:45 before the stop, +2R 12:16; at 15:50 +3.1R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:32",
    "ticker": "NXG",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 13.09,
    "stop": 13.15,
    "rvol": 2.6,
    "scanner": "down -2.6% vs index, VWAP falling, 3 of the last 20 bars above VWAP, closed back below it at 13.09 (VWAP 13.1)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:33",
     "first": "stop",
     "stop_touched": "11:47",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -1.0,
     "best_r": 0.0,
     "worst_r": -1.5,
     "line": "stop touched 11:47 before +1R; at 15:50 -1.0R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:38",
    "ticker": "AUB",
    "setup": "opening_range_breakout",
    "side": "short",
    "last": 26.96,
    "stop": 27.62,
    "rvol": 1.8,
    "scanner": "closed 26.96 below the 30-min low 27.48 on 71.6x the prior 10 bars' volume, RVOL 1.8",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:39",
     "first": "neither",
     "stop_touched": null,
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": 0.16,
     "best_r": 0.17,
     "worst_r": -0.27,
     "line": "neither the stop nor +1R by 15:50; at 15:50 +0.2R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:38",
    "ticker": "ORI",
    "setup": "opening_range_breakout",
    "side": "short",
    "last": 22.62,
    "stop": 23.0675,
    "rvol": 1.6,
    "scanner": "closed 22.62 below the 30-min low 22.95 on 5.7x the prior 10 bars' volume, RVOL 1.6",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:39",
     "first": "neither",
     "stop_touched": null,
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -0.41,
     "best_r": 0.07,
     "worst_r": -0.45,
     "line": "neither the stop nor +1R by 15:50; at 15:50 -0.4R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:38",
    "ticker": "XYZ",
    "setup": "vwap_reclaim",
    "side": "buy",
    "last": 108.85,
    "stop": 108.76,
    "rvol": 1.3,
    "scanner": "up +3.1% vs index, VWAP rising, 4 of the last 20 bars below VWAP, closed back above it at 108.8 (VWAP 108.8)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:39",
     "first": "stop",
     "stop_touched": "11:56",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -4.33,
     "best_r": 0.89,
     "worst_r": -7.56,
     "line": "stop touched 11:56 before +1R; at 15:50 -4.3R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:40",
    "ticker": "CHC",
    "setup": "opening_range_breakout",
    "side": "short",
    "last": 17.63,
    "stop": 17.82,
    "rvol": 1.6,
    "scanner": "closed 17.63 below the 30-min low 17.71 on 4.0x the prior 10 bars' volume, RVOL 1.6",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:41",
     "first": "neither",
     "stop_touched": null,
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": 0.11,
     "best_r": 0.45,
     "worst_r": -0.53,
     "line": "neither the stop nor +1R by 15:50; at 15:50 +0.1R (price path before costs, no trade management)"
    }
   },
   {
    "at": "11:47",
    "ticker": "AAI",
    "setup": "opening_range_breakout",
    "side": "buy",
    "last": 61.02,
    "stop": 60.65,
    "rvol": 1.9,
    "scanner": "closed 61.02 above the 30-min high 61 on 4.2x the prior 10 bars' volume, RVOL 1.9",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "11:48",
     "first": "neither",
     "stop_touched": null,
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": 0.3,
     "best_r": 0.39,
     "worst_r": -0.84,
     "line": "neither the stop nor +1R by 15:50; at 15:50 +0.3R (price path before costs, no trade management)"
    }
   },
   {
    "at": "12:03",
    "ticker": "MIN",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 52.72,
    "stop": 52.83,
    "rvol": 1.1,
    "scanner": "down -2.1% vs index, VWAP falling, 8 of the last 20 bars above VWAP, closed back below it at 52.72 (VWAP 52.74)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "12:04",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "12:04",
     "plus_2r": "12:04",
     "r_at_1550": 5.73,
     "best_r": 14.68,
     "worst_r": 0.0,
     "line": "+1R at 12:04 before the stop, +2R 12:04; at 15:50 +5.7R (price path before costs, no trade management)"
    }
   },
   {
    "at": "12:15",
    "ticker": "BRG",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 29.985,
    "stop": 30.03,
    "rvol": 0.9,
    "scanner": "down -1.4% vs index, VWAP falling, 10 of the last 20 bars above VWAP, closed back below it at 29.98 (VWAP 29.99)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "12:16",
     "first": "+1R",
     "stop_touched": "13:07",
     "plus_1r": "12:24",
     "plus_2r": "12:34",
     "r_at_1550": 1.44,
     "best_r": 6.33,
     "worst_r": -2.78,
     "line": "+1R at 12:24 before the stop, +2R 12:34; stop touched later (13:07); at 15:50 +1.4R (price path before costs, no trade management)"
    }
   },
   {
    "at": "12:25",
    "ticker": "REA",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 148.21,
    "stop": 148.4,
    "rvol": 1.7,
    "scanner": "down -2.0% vs index, VWAP falling, 8 of the last 20 bars above VWAP, closed back below it at 148.2 (VWAP 148.2)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "12:26",
     "first": "stop",
     "stop_touched": "12:30",
     "plus_1r": "12:56",
     "plus_2r": "13:50",
     "r_at_1550": 3.71,
     "best_r": 6.13,
     "worst_r": -2.18,
     "line": "stop touched 12:30 before +1R; at 15:50 +3.7R (price path before costs, no trade management)"
    }
   },
   {
    "at": "12:33",
    "ticker": "SGM",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 24.25,
    "stop": 24.35,
    "rvol": 0.6,
    "scanner": "down -1.3% vs index, VWAP falling, 10 of the last 20 bars above VWAP, closed back below it at 24.25 (VWAP 24.27)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "12:34",
     "first": "stop",
     "stop_touched": "13:21",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": 0.15,
     "best_r": 0.7,
     "worst_r": -1.3,
     "line": "stop touched 13:21 before +1R; at 15:50 +0.1R (price path before costs, no trade management)"
    }
   },
   {
    "at": "12:47",
    "ticker": "PME",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 159.71,
    "stop": 160.24,
    "rvol": 1.0,
    "scanner": "down -1.7% vs index, VWAP falling, 6 of the last 20 bars above VWAP, closed back below it at 159.7 (VWAP 159.8)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "12:48",
     "first": "stop",
     "stop_touched": "13:02",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -3.25,
     "best_r": 0.11,
     "worst_r": -4.0,
     "line": "stop touched 13:02 before +1R; at 15:50 -3.3R (price path before costs, no trade management)"
    }
   },
   {
    "at": "12:57",
    "ticker": "DRR",
    "setup": "opening_range_breakout",
    "side": "short",
    "last": 4.03,
    "stop": 4.145,
    "rvol": 1.5,
    "scanner": "closed 4.03 below the 30-min low 4.12 on 3.7x the prior 10 bars' volume, RVOL 1.5",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "12:58",
     "first": "neither",
     "stop_touched": null,
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -0.22,
     "best_r": 0.09,
     "worst_r": -0.35,
     "line": "neither the stop nor +1R by 15:50; at 15:50 -0.2R (price path before costs, no trade management)"
    }
   },
   {
    "at": "13:00",
    "ticker": "AIA",
    "setup": "vwap_reclaim",
    "side": "buy",
    "last": 6.93,
    "stop": 6.92,
    "rvol": 2.1,
    "scanner": "up +3.2% vs index, VWAP rising, 3 of the last 20 bars below VWAP, closed back above it at 6.93 (VWAP 6.929)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "13:01",
     "first": "stop",
     "stop_touched": "13:06",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -4.5,
     "best_r": 0.5,
     "worst_r": -6.0,
     "line": "stop touched 13:06 before +1R; at 15:50 -4.5R (price path before costs, no trade management)"
    }
   },
   {
    "at": "13:00",
    "ticker": "ALL",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 58.12,
    "stop": 58.22,
    "rvol": 0.9,
    "scanner": "down -2.4% vs index, VWAP falling, 8 of the last 20 bars above VWAP, closed back below it at 58.12 (VWAP 58.13)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "13:01",
     "first": "stop",
     "stop_touched": "13:01",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -2.05,
     "best_r": 0.0,
     "worst_r": -4.6,
     "line": "stop touched 13:01 before +1R; at 15:50 -2.1R (price path before costs, no trade management)"
    }
   },
   {
    "at": "13:20",
    "ticker": "CQR",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 3.56,
    "stop": 3.565,
    "rvol": 2.3,
    "scanner": "down -1.1% vs index, VWAP falling, 20 of the last 20 bars above VWAP, closed back below it at 3.56 (VWAP 3.56)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "13:21",
     "first": "stop",
     "stop_touched": "13:21",
     "plus_1r": "13:40",
     "plus_2r": "13:40",
     "r_at_1550": 3.0,
     "best_r": 4.0,
     "worst_r": -2.0,
     "line": "stop touched 13:21 before +1R; at 15:50 +3.0R (price path before costs, no trade management)"
    }
   },
   {
    "at": "13:29",
    "ticker": "PMV",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 11.76,
    "stop": 11.79,
    "rvol": 1.7,
    "scanner": "down -1.0% vs index, VWAP falling, 6 of the last 20 bars above VWAP, closed back below it at 11.76 (VWAP 11.77)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "13:30",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "13:39",
     "plus_2r": "13:46",
     "r_at_1550": 0.67,
     "best_r": 3.33,
     "worst_r": -0.67,
     "line": "+1R at 13:39 before the stop, +2R 13:46; at 15:50 +0.7R (price path before costs, no trade management)"
    }
   },
   {
    "at": "13:31",
    "ticker": "IAG",
    "setup": "vwap_reclaim",
    "side": "buy",
    "last": 7.88,
    "stop": 7.87,
    "rvol": 1.7,
    "scanner": "up +1.4% vs index, VWAP rising, 14 of the last 20 bars below VWAP, closed back above it at 7.88 (VWAP 7.877)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "13:32",
     "first": "stop",
     "stop_touched": "13:32",
     "plus_1r": "15:15",
     "plus_2r": "15:15",
     "r_at_1550": 1.0,
     "best_r": 7.0,
     "worst_r": -5.0,
     "line": "stop touched 13:32 before +1R; at 15:50 +1.0R (price path before costs, no trade management)"
    }
   },
   {
    "at": "13:31",
    "ticker": "L1G",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 1.177,
    "stop": 1.18,
    "rvol": 1.0,
    "scanner": "down -1.2% vs index, VWAP falling, 19 of the last 20 bars above VWAP, closed back below it at 1.177 (VWAP 1.18)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "13:34",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "13:36",
     "plus_2r": "13:40",
     "r_at_1550": 5.67,
     "best_r": 7.33,
     "worst_r": 0.0,
     "line": "+1R at 13:36 before the stop, +2R 13:40; at 15:50 +5.7R (price path before costs, no trade management)"
    }
   },
   {
    "at": "13:35",
    "ticker": "JBH",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 66.34,
    "stop": 66.47,
    "rvol": 1.3,
    "scanner": "down -1.7% vs index, VWAP falling, 18 of the last 20 bars above VWAP, closed back below it at 66.34 (VWAP 66.38)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "13:36",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "14:12",
     "plus_2r": null,
     "r_at_1550": 0.27,
     "best_r": 1.15,
     "worst_r": -0.62,
     "line": "+1R at 14:12 before the stop; at 15:50 +0.3R (price path before costs, no trade management)"
    }
   },
   {
    "at": "13:39",
    "ticker": "EOS",
    "setup": "vwap_reclaim",
    "side": "buy",
    "last": 11.31,
    "stop": 11.23,
    "rvol": 1.9,
    "scanner": "up +6.1% vs index, VWAP rising, 5 of the last 20 bars below VWAP, closed back above it at 11.31 (VWAP 11.27)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "13:40",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "13:41",
     "plus_2r": "13:46",
     "r_at_1550": 1.12,
     "best_r": 3.87,
     "worst_r": 0.0,
     "line": "+1R at 13:41 before the stop, +2R 13:46; at 15:50 +1.1R (price path before costs, no trade management)"
    }
   },
   {
    "at": "13:56",
    "ticker": "PRN",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 2.19,
    "stop": 2.2,
    "rvol": 0.4,
    "scanner": "down -1.0% vs index, VWAP falling, 17 of the last 20 bars above VWAP, closed back below it at 2.19 (VWAP 2.194)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "13:57",
     "first": "stop",
     "stop_touched": "14:24",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -0.5,
     "best_r": 0.5,
     "worst_r": -1.0,
     "line": "stop touched 14:24 before +1R; at 15:50 -0.5R (price path before costs, no trade management)"
    }
   },
   {
    "at": "14:00",
    "ticker": "MTS",
    "setup": "vwap_reclaim",
    "side": "buy",
    "last": 2.85,
    "stop": 2.84,
    "rvol": 0.9,
    "scanner": "up +1.0% vs index, VWAP rising, 8 of the last 20 bars below VWAP, closed back above it at 2.85 (VWAP 2.846)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "14:01",
     "first": "neither",
     "stop_touched": null,
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": 1.0,
     "best_r": 1.0,
     "worst_r": -0.5,
     "line": "neither the stop nor +1R by 15:50; at 15:50 +1.0R (price path before costs, no trade management)"
    }
   },
   {
    "at": "14:13",
    "ticker": "ORI",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 22.74,
    "stop": 22.77,
    "rvol": 1.2,
    "scanner": "down -1.3% vs index, VWAP falling, 9 of the last 20 bars above VWAP, closed back below it at 22.74 (VWAP 22.75)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "14:14",
     "first": "stop",
     "stop_touched": "14:16",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -2.17,
     "best_r": 0.33,
     "worst_r": -2.67,
     "line": "stop touched 14:16 before +1R; at 15:50 -2.2R (price path before costs, no trade management)"
    }
   },
   {
    "at": "14:15",
    "ticker": "RPL",
    "setup": "opening_range_breakout",
    "side": "buy",
    "last": 2.265,
    "stop": 2.245,
    "rvol": 2.8,
    "scanner": "closed 2.265 above the 30-min high 2.26 on 63.9x the prior 10 bars' volume, RVOL 2.8",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "14:18",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "14:49",
     "plus_2r": "15:42",
     "r_at_1550": 1.75,
     "best_r": 2.25,
     "worst_r": -0.25,
     "line": "+1R at 14:49 before the stop, +2R 15:42; at 15:50 +1.7R (price path before costs, no trade management)"
    }
   },
   {
    "at": "14:15",
    "ticker": "APE",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 18.72,
    "stop": 18.77,
    "rvol": 1.0,
    "scanner": "down -2.9% vs index, VWAP falling, 7 of the last 20 bars above VWAP, closed back below it at 18.72 (VWAP 18.74)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "14:16",
     "first": "+1R",
     "stop_touched": null,
     "plus_1r": "14:36",
     "plus_2r": "14:36",
     "r_at_1550": 3.8,
     "best_r": 4.0,
     "worst_r": -0.4,
     "line": "+1R at 14:36 before the stop, +2R 14:36; at 15:50 +3.8R (price path before costs, no trade management)"
    }
   },
   {
    "at": "14:29",
    "ticker": "ORA",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 1.39,
    "stop": 1.395,
    "rvol": 0.7,
    "scanner": "down -1.1% vs index, VWAP falling, 16 of the last 20 bars above VWAP, closed back below it at 1.39 (VWAP 1.391)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "14:30",
     "first": "+1R",
     "stop_touched": "15:36",
     "plus_1r": "14:48",
     "plus_2r": null,
     "r_at_1550": -1.0,
     "best_r": 1.0,
     "worst_r": -2.0,
     "line": "+1R at 14:48 before the stop; stop touched later (15:36); at 15:50 -1.0R (price path before costs, no trade management)"
    }
   },
   {
    "at": "14:31",
    "ticker": "SDF",
    "setup": "opening_range_breakout",
    "side": "buy",
    "last": 5.76,
    "stop": 5.745,
    "rvol": 1.5,
    "scanner": "closed 5.76 above the 30-min high 5.75 on 14.1x the prior 10 bars' volume, RVOL 1.5",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "14:32",
     "first": "stop",
     "stop_touched": "14:40",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -0.67,
     "best_r": 0.0,
     "worst_r": -1.33,
     "line": "stop touched 14:40 before +1R; at 15:50 -0.7R (price path before costs, no trade management)"
    }
   },
   {
    "at": "14:51",
    "ticker": "REH",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 16.29,
    "stop": 16.305,
    "rvol": 0.8,
    "scanner": "down -2.0% vs index, VWAP falling, 8 of the last 20 bars above VWAP, closed back below it at 16.29 (VWAP 16.3)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "14:52",
     "first": "stop",
     "stop_touched": "14:53",
     "plus_1r": "15:03",
     "plus_2r": "15:08",
     "r_at_1550": 3.33,
     "best_r": 3.33,
     "worst_r": -1.67,
     "line": "stop touched 14:53 before +1R; at 15:50 +3.3R (price path before costs, no trade management)"
    }
   },
   {
    "at": "14:54",
    "ticker": "CIA",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 3.095,
    "stop": 3.11,
    "rvol": 0.8,
    "scanner": "down -1.8% vs index, VWAP falling, 8 of the last 20 bars above VWAP, closed back below it at 3.095 (VWAP 3.104)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "14:55",
     "first": "stop",
     "stop_touched": "15:44",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": -1.0,
     "best_r": 0.33,
     "worst_r": -1.67,
     "line": "stop touched 15:44 before +1R; at 15:50 -1.0R (price path before costs, no trade management)"
    }
   },
   {
    "at": "15:12",
    "ticker": "DRR",
    "setup": "vwap_reclaim",
    "side": "short",
    "last": 4.06,
    "stop": 4.07,
    "rvol": 1.5,
    "scanner": "down -1.9% vs index, VWAP falling, 6 of the last 20 bars above VWAP, closed back below it at 4.06 (VWAP 4.062)",
    "decision": "skipped",
    "why": "the account is full (3 open or working)",
    "after": {
     "from": "15:13",
     "first": "stop",
     "stop_touched": "15:14",
     "plus_1r": null,
     "plus_2r": null,
     "r_at_1550": 0.5,
     "best_r": 1.0,
     "worst_r": -1.0,
     "line": "stop touched 15:14 before +1R; at 15:50 +0.5R (price path before costs, no trade management)"
    }
   }
  ],
  "setups_not_decided": {
   "stale: the trigger bar is N bars old": 28
  },
  "decisions": 39
 },
 "entry": "",
 "lesson": "",
 "written_by": "code",
 "call": null
}
```
